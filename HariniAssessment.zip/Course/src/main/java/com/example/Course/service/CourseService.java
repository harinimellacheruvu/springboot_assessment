package com.example.Course.service;

import java.util.List;
import com.example.Course.dto.CourseDto;
import com.example.Course.Exception.CourseNotFoundException;

public interface CourseService {
    CourseDto createCourse(CourseDto CourseDto);

    CourseDto getCourseById(Long CourseId) throws CourseNotFoundException;

    List<CourseDto> getCourses();

    void deleteCourse(Long CourseId) throws CourseNotFoundException;

    CourseDto updateCourse(CourseDto CourseDto) throws CourseNotFoundException;

}
