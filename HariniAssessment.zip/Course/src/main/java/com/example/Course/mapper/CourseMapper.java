package com.example.Course.mapper;

import com.example.Course.dto.CourseDto;
import com.example.Course.entity.Course;

public class CourseMapper {

    public static CourseDto mapToCourseDto(Course course) {
        return new CourseDto(course.getId(), course.getName(), course.getDescription(), course.getDuration());
    }

    public static Course mapToCourse(CourseDto courseDto) {
        return new Course(courseDto.getId(), courseDto.getName(), courseDto.getDescription(), courseDto.getDuration());
    }

}
