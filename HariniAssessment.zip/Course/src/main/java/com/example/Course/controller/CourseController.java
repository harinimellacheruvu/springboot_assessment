package com.example.Course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Course.dto.CourseDto;
import com.example.Course.Exception.CourseNotFoundException;
import com.example.Course.service.CourseService;

@RestController
public class CourseController {

    @Autowired
    private CourseService CourseService;

    @PostMapping(value = "/Course")
    public ResponseEntity<CourseDto> createCourse(@RequestBody CourseDto CourseDto) {
        CourseDto createdCourse = CourseService.createCourse(CourseDto);
        return new ResponseEntity<>(createdCourse, HttpStatus.CREATED);
    }

    @GetMapping(value = "/Course/{CourseId}")
    public ResponseEntity<CourseDto> getCourseById(@PathVariable("CourseId") Long CourseId)
            throws CourseNotFoundException {
        try {
            CourseDto Course = CourseService.getCourseById(CourseId);
            return new ResponseEntity<>(Course, HttpStatus.OK);
        } catch (CourseNotFoundException CourseNotFoundException) {
            throw CourseNotFoundException;
        }
    }

    @GetMapping(value = "/Courses")
    public ResponseEntity<List<CourseDto>> getCourses() {
        List<CourseDto> Courses = CourseService.getCourses();
        return new ResponseEntity<>(Courses, HttpStatus.OK);
    }

    @DeleteMapping(value = "/Course/{CourseId}")
    public ResponseEntity<HttpStatus> deleteCourses(@PathVariable("CourseId") Long CourseId)
            throws CourseNotFoundException {
        CourseService.deleteCourse(CourseId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping(value = "/Course")
    public ResponseEntity<CourseDto> updateCourse(@RequestBody CourseDto CourseDto)
            throws CourseNotFoundException {
        CourseDto createdCourse = CourseService.updateCourse(CourseDto);
        return new ResponseEntity<>(createdCourse, HttpStatus.OK);
    }
}
