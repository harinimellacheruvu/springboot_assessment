package com.example.Course.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Course.dto.CourseDto;
import com.example.Course.entity.Course;
import com.example.Course.Exception.CourseNotFoundException;
import com.example.Course.mapper.CourseMapper;
import com.example.Course.Repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseRepository CourseRepository;

    @Override
    public CourseDto createCourse(CourseDto CourseDto) {
        Course Course = CourseMapper.mapToCourse(CourseDto);
        Course createdCourse = CourseRepository.save(Course);
        return CourseMapper.mapToCourseDto(createdCourse);
    }

    @Override
    public CourseDto getCourseById(Long CourseId) throws CourseNotFoundException {
        Optional<Course> Course = CourseRepository.findById(CourseId);
        if (Course.isEmpty()) {
            throw new CourseNotFoundException("Course with id - " + CourseId + " not found.");
        }
        return CourseMapper.mapToCourseDto(Course.get());
    }

    @Override
    public List<CourseDto> getCourses() {
        List<Course> Courses = CourseRepository.findAll();
        return Courses.stream().map((emp) -> CourseMapper.mapToCourseDto(emp)).collect(Collectors.toList());
    }

    @Override
    public void deleteCourse(Long CourseId) throws CourseNotFoundException {
        Optional<Course> Course = CourseRepository.findById(CourseId);
        if (Course.isEmpty()) {
            throw new CourseNotFoundException("Course with id - " + CourseId + " not found.");
        }
        CourseRepository.deleteById(CourseId);
    }

    @Override
    public CourseDto updateCourse(CourseDto CourseDto) throws CourseNotFoundException {
        Optional<Course> retrievedCourse = CourseRepository.findById(CourseDto.getId());
        if (retrievedCourse.isEmpty()) {
            throw new CourseNotFoundException("Course with id - " + CourseDto.getId() + " not found.");
        }
        Course Course = retrievedCourse.get();
        Course.setName(CourseDto.getName());
        Course.setDescription(CourseDto.getDescription());
        Course.setDuration(CourseDto.getDescription());
        Course createdCourse = CourseRepository.save(Course);
        return CourseMapper.mapToCourseDto(createdCourse);
    }
}
